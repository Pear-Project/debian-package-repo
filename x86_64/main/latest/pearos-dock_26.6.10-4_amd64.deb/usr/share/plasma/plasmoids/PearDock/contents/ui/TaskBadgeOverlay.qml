/*
    SPDX-FileCopyrightText: 2016 Kai Uwe Broulik <kde@privat.broulik.de>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.graphicaleffects as KGraphicalEffects
import org.kde.plasma.plasmoid

Item {
    id: root

    readonly property int iconWidthDelta: (icon.width - icon.paintedWidth) / 4
    readonly property bool shiftBadgeDown: (Plasmoid.pluginName === "PearDock") && task.audioStreamIcon !== null

    Item {
        id: badgeMask
        anchors.fill: parent

        Rectangle {
            readonly property int offset: Math.round(Math.max(Kirigami.Units.smallSpacing / 2, badgeMask.width / 32))

            anchors.right: parent.right
            anchors.rightMargin: -offset
            y: root.shiftBadgeDown ? (icon.height / 2) : 0

            Behavior on y {
                NumberAnimation { duration: Kirigami.Units.longDuration }
            }

            visible: task.smartLauncherItem.countVisible
            width: badgeRect.width + offset * 2
            height: badgeRect.height + offset * 2
            radius: badgeRect.radius + offset * 2

            // Badge changes width based on number.
            onWidthChanged: maskShaderSource.scheduleUpdate()
            onVisibleChanged: maskShaderSource.scheduleUpdate()
            onYChanged: maskShaderSource.scheduleUpdate()
        }
    }

    ShaderEffectSource {
        id: iconShaderSource
        sourceItem: icon
        hideSource: GraphicsInfo.api !== GraphicsInfo.Software
    }

    ShaderEffectSource {
        id: maskShaderSource
        sourceItem: badgeMask
        hideSource: true
        live: false
    }

    KGraphicalEffects.BadgeEffect {
        id: shader

        anchors.top: parent.top
        anchors.topMargin: (Kirigami.Units.smallSpacing * 0.7)
        anchors.bottom: parent.bottom
        anchors.bottomMargin: (Kirigami.Units.smallSpacing * 0.7)
        anchors.left: parent.left
        anchors.right: parent.right

        width: icon.paintedWidth / 2
        height: icon.paintedWidth / 2

        source: iconShaderSource
        mask: maskShaderSource

        onWidthChanged: maskShaderSource.scheduleUpdate()
        onHeightChanged: maskShaderSource.scheduleUpdate()
    }

    Badge {
        id: badgeRect

        anchors.right: parent.right

        y: {
            const offset = Math.round(Math.max(Kirigami.Units.smallSpacing / 2, badgeMask.width / 32));
            return offset + (root.shiftBadgeDown ? (icon.height / 2) : 0);
        }

        Behavior on y {
            NumberAnimation { duration: Kirigami.Units.longDuration }
        }

        height: Math.round((icon.height/2) * 0.45)
        visible: task.smartLauncherItem.countVisible
        number: task.smartLauncherItem.count
    }
}
