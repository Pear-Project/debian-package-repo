import QtQuick

QtObject {
    property string imageTop: "bgt.png"
    property string imageBottom: "bg.png"
    property string imageLeft: "bgl.png"
    property string imageRight: "bgr.png"
    property string imagetask: "tasks.svgz"
    property bool blur: true
    property int blurRadius: 24
    property bool liquidGelEffect: true
    property real refractionStrength: 8.0
    property real rgbFringing: 2.0
    property int positionTaskIndicator: 3
    property int leftMargin: 20
    property int topMargin: 20
    property int rightMargin: 20
    property int bottomMargin: 20
    property int outsideLeftMargin: 20
    property int outsideTopMargin: 10
    property int outsideRightMargin: 20
    property int outsideBottomMargin: -8
}
