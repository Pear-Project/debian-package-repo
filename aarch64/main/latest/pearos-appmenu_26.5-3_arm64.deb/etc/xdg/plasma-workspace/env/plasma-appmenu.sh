#!/bin/sh
export QT_PLUGIN_PATH="/usr/lib/qt6/plugins-appmenu${QT_PLUGIN_PATH:+:$QT_PLUGIN_PATH}"
